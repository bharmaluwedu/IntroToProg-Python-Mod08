from unittest import TestCase
import tempfile
import json
import data_classes as data
from processing_classes import FileProcessor

class TestFileProcessor(TestCase):
    """
    Testing the collection of processing layer functions that work with Json files

    ChangeLog: Mohammad Ammar Bharmal, 03.09.2024, Created Class
    RRoot,1.1.2030,Created Class
    """
    def setUp(self):
        '''
        sets environment for each testing function BEFORE running so that all the test functions are independent on the result of the previously ran test function
        '''
        self.temp_file = tempfile.NamedTemporaryFile(delete=False)
        self.temp_file_name = self.temp_file.name
        self.employee_data = []

    def tearDown(self):
        self.temp_file.close()

    def test_write_employee_data_to_file(self):
        """ This function tests the function that writes data to a json file with data from a list of dictionary rows

        ChangeLog: Mohammad Ammar Bharmal, 03.09.2024, Created function
        RRoot,1.1.2030,Created function

        :param temp_file_name: string data with name of file to write to
        :param sample_employees: list of dictionary rows to be writen to the file

        :return: None
        """
        sample_employees = [
            data.Employee("John", "Doe", "2024-03-05", 3),
            data.Employee("Alice", "Smith", "2020-07-09", 5)
        ]

        FileProcessor.write_employee_data_to_file(self.temp_file_name, sample_employees)

        with open(self.temp_file_name, "r") as file:
            file_data = json.load(file)

        self.assertEqual(len(file_data), len(sample_employees))
        self.assertEqual(file_data[0]["FirstName"], "John")
        self.assertEqual(file_data[1]["ReviewRating"], 5)

    def test_read_employee_data_from_file(self):
        """ This function tests the function that reads data from a json file and loads it into a list of dictionary rows

        ChangeLog: Mohammad Ammar Bharmal, 03.09.2024, Created function
        RRoot,1.1.2030,Created function

        :param file_name: string data with name of file to read from
        :param employee_data: list of dictionary rows to be filled with file data

        :return: None
        """
        sample_data = [
            {"FirstName": "John", "LastName": "Doe", "ReviewDate": "2024-03-05", "ReviewRating": 3},
            {"FirstName": "Alice", "LastName": "Smith", "ReviewDate": "2020-07-09", "ReviewRating": 5},
        ]

        #Populate the temp file
        with open(self.temp_file_name, "w") as file:
            json.dump(sample_data, file)

        FileProcessor.read_employee_data_from_file(self.temp_file_name, self.employee_data, data.Employee)

        self.assertEqual(len(self.employee_data), len(sample_data))
        self.assertEqual(self.employee_data[0].first_name, "John")
        self.assertEqual(self.employee_data[1].review_rating, 5)
