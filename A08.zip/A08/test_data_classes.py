import unittest
from data_classes import Person, Employee

class TestPerson(unittest.TestCase):
    """
    Testing the class representing person data.

    Properties:
    - first_name (str): The person's first name.
    - last_name (str): The person's last name.

    ChangeLog: Mohammad Ammar Bharmal, 03.09.2024, Created the class
    - RRoot, 1.1.2030: Created the class.
    """
    def test_Person_init(self):
        person = Person("John", "Doe")
        self.assertEqual(person.first_name, "John")
        self.assertEqual(person.last_name, "Doe")

    def test_person_invalid_first_name(self):
        with self.assertRaises(ValueError):
            Person("123", "Doe")

    def test_person_invalid_last_name(self):
        with self.assertRaises(ValueError):
            Person("John", "123")

    def test___str__(self):
        person = Person("Alice", "Smith")
        self.assertEqual(person.__str__(),"Alice,Smith")

class TestStudent(unittest.TestCase):
    """
    Testing the class representing employee data.

    Properties:
    - first_name (str): The employee's first name.
    - last_name (str): The employee's last name.
    - review_date (date): The data of the employee review.
    - review_rating (int): The review rating of the employee's performance (1-5)

    ChangeLog: Mohammad Ammar Bharmal, 03.09.2024, Created the class
    - RRoot, 1.1.2030: Created the class.
    """
    def test_student_init(self):
        employee = Employee("Alice", "Smith", "2021-05-09", 4)
        self.assertEqual(employee.first_name, "Alice")
        self.assertEqual(employee.last_name, "Smith")
        self.assertEqual(employee.review_date, "2021-05-09")
        self.assertEqual(employee.review_rating, 4)

    def test_employee_invalid_review_date(self):
        with self.assertRaises(ValueError):
            Employee("Alice", "Smith", "09-05-2021", 4)

    def test_employee_invalid_review_rating(self):
        with self.assertRaises(ValueError):
            Employee("Alice", "Smith", "2021-05-09", 7)

    def test___str__(self):
        employee = Employee("Alice", "Smith", "2021-05-09", 4)
        self.assertEqual(employee.__str__(),"Alice,Smith,2021-05-09,4")
      # return f"{self.first_name},{self.last_name},{self.review_date},{self.__review_rating}"
