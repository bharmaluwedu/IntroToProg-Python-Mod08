import unittest
from unittest.mock import patch
from presentation_classes import IO
from data_classes import Employee

class TestIO(unittest.TestCase):
    """
    Testing the collection of presentation layer test functions that manage user input and output

    ChangeLog: Mohammad Ammar Bharmal, 03.09.2024, Created Class
    RRoot,1.1.2030,Created Class
    """
    #pass

    def setUp(self):
        '''
        sets environment for each testing function BEFORE running so that all the test functions are independent on the result of the previously ran test function
        '''
        self.employee_data = []

    def test_input_employee_data(self):
        """ This function tests the function that gets the first name, last name, review date and review rating from the user

        ChangeLog: Mohammad Ammar Bharmal, 03.09.2024, Created function
        RRoot,1.1.2030,Created function

        :param employee_data: list of dictionary rows to be filled with input data

        :return: list
        """
        with patch('builtins.input', side_effect=('John', 'Doe', '2020-03-07', '4')):
            IO.input_employee_data(self.employee_data, Employee)
            self.assertEqual(self.employee_data[0].first_name, 'John')
            self.assertEqual(self.employee_data[0].last_name, 'Doe')
            self.assertEqual(self.employee_data[0].review_date, '2020-03-07')
            self.assertEqual(self.employee_data[0].review_rating, 4)
            length_of_employee_list = len(self.employee_data)
            self.assertEqual(length_of_employee_list, 1)

    def test_input_employee_data_invalid_review_rating(self):
        with patch('builtins.input', side_effect=('John', 'Doe', '2020-03-07', 'no review rating data')):
            IO.input_employee_data(self.employee_data, Employee)
            length_of_employee_list = len(self.employee_data)
            self.assertEqual(length_of_employee_list, 0)
